using UnityEngine;
using UnityEngine.Events;

public class RheostatController : MonoBehaviour
{
    [Header("Resistance")]
    [SerializeField] private float maxResistance = 100f;
    [SerializeField] private float minResistance = 13f;
    [SerializeField] private float resistanceStep = 20f;

    [Header("Rotation")]
    [SerializeField] private float rotationPerClick = 5f;

    [Header("PV Graph")]
    [SerializeField] private PVGraphController pvGraphController;

    [Header("Events")]
    public UnityEvent OnMinimumReached;

    public float CurrentResistance => currentResistance;

    public void ConfigureFreeModeRange(float maximum, float minimum, float step)
    {
        if (TutorialFramework.InteractionManager.Instance == null ||
            !TutorialFramework.InteractionManager.Instance.Free) return;
        maxResistance = maximum;
        minResistance = Mathf.Clamp(minimum, .01f, maximum);
        resistanceStep = Mathf.Max(.01f, step);
        currentResistance = maximum;
        minimumEventFired = false;
        SetRotation();
    }

    private float currentResistance;
    private bool minimumEventFired = false;

    private void Start()
    {
        currentResistance = maxResistance;
        minimumEventFired = false;
        SetRotation();
    }

    public void IncreaseValue()
    {
        if (currentResistance >= maxResistance)
            return;

        currentResistance = Mathf.Min(currentResistance + resistanceStep, maxResistance);
        SetRotation();
        UpdateGraph();
        CheckMinimum();
    }

    public void DecreaseValue()
    {
        if (currentResistance <= minResistance)
            return;

        currentResistance = Mathf.Max(currentResistance - resistanceStep, minResistance);
        SetRotation();
        UpdateGraph();
        CheckMinimum();
    }

    private void UpdateGraph()
    {
        if (pvGraphController != null)
            pvGraphController.UpdateMeasurement(currentResistance, this);
    }

    private void CheckMinimum()
    {
        if (currentResistance <= minResistance && !minimumEventFired)
        {
            minimumEventFired = true;
            OnMinimumReached?.Invoke();
            Debug.Log("Rheostat has reached minimum resistance!");
        }
    }

    private void SetRotation()
    {
        float steps = (maxResistance - currentResistance) / resistanceStep;
        float xRotation = steps * rotationPerClick;
        Vector3 currentEuler = transform.localEulerAngles;
        transform.localRotation = Quaternion.Euler(xRotation, currentEuler.y, currentEuler.z);
    }
}
